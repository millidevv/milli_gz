local inGZ = false

CreateThread(function()
    for _, zone in ipairs(Config.GreenZones) do
        local blip = AddBlipForRadius(zone.x, zone.y, zone.z, zone.w)
        SetBlipSprite(blip, 9)
        SetBlipColour(blip, 2)
        SetBlipAlpha(blip, 100)

        local point = lib.points.new({
            coords = zone.xyz,
            distance = zone.w,
        })

        function point:onEnter()
            SendNUIMessage({ action = 'toggleImage', isVisible = true })
            inGZ = true
            SetLocalPlayerAsGhost(true)
            SetGhostedEntityAlpha(220)
            local playerPed = cache.ped
            SetEntityCanBeDamaged(playerPed, false)
            SetPlayerCanDoDriveBy(playerPed, false)
            if cache.vehicle then
                SetEntityMaxSpeed(cache.vehicle, Config.VehicleMaxSpeed)
            end
        end

        function point:onExit()
            SendNUIMessage({ action = 'toggleImage', isVisible = false })
            inGZ = false
            SetLocalPlayerAsGhost(false)
            SetGhostedEntityAlpha(255)
            local playerPed = cache.ped
            SetEntityCanBeDamaged(playerPed, true)
            SetPlayerCanDoDriveBy(playerPed, true)
            if cache.vehicle then
                SetEntityMaxSpeed(cache.vehicle,
                    GetVehicleHandlingFloat(cache.vehicle, "CHandlingData", "fInitialDriveMaxFlatVel"))
            end
        end

        function point:nearby()
            local playerPed = cache.ped
            SetEntityCanBeDamaged(playerPed, false)
            SetPlayerCanDoDriveBy(playerPed, false)
            DisableControlAction(0, 140)
            if cache.vehicle then
                SetEntityMaxSpeed(cache.vehicle, Config.VehicleMaxSpeed)
            end
            DisablePlayerFiring(cache.playerId, true)
            local weapon = exports.ox_inventory:getCurrentWeapon()
            if weapon and weapon.hash then
                TriggerEvent('ox_inventory:disarm')
            end
        end
    end
end)
