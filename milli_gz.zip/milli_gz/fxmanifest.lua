fx_version 'cerulean'
games { 'gta5' }
author 'Milli'
discord 'https://discord.gg/loststudios'
lua54 'yes'


shared_scripts {
    '@ox_lib/init.lua',
    'config.lua',
}

client_script 'client/client.lua'

ui_page 'web/index.html'

files {
    'web/index.html',
    'web/image.png',
}