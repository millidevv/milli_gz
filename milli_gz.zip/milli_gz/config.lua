Config = {}

Config.GreenZones = {
    vec4(288.4843, -1601.2721, 31.2599, 50.0), -- First Spawn Area Postal 832
    vec4(-284.3298, 562.4928, 173.8185, 40.0), -- First Spawn Location After Character Creation 
}

Config.VehicleMaxSpeed = 20.0